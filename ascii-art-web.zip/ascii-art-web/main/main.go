package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"strings"

	art "../ascii-art"
)

type Banner struct {
	Data interface{}
}

func handler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		fmt.Fprint(w, "404 Page Not Found")
		return
	}
	t, err := template.ParseFiles("main.html")
	if err != nil {
		fmt.Fprintf(w,"500 Internal Server Error")
		return
	}
	t.Execute(w, nil)
}

func print(w http.ResponseWriter, r *http.Request) {
	var val string
	var err error
	res := ""
	value := r.FormValue("words")
	bannerType := r.FormValue("type")
	banners,err := art.GetBanners(bannerType + ".txt")
	if err != nil {
		fmt.Fprintf(w,"400 Bad Request")
		return
	}
	values := strings.Split(value, "\\n")
	for _, i := range values {
		val, err = art.CombineBanners(banners, i)
		if err != nil {
			fmt.Fprintf(w, "400 Bad Request")
			return
		}
		res += val
	}

	b := Banner{res}
	t, err := template.ParseFiles("main.html")
	if err != nil {
		fmt.Fprintf(w,"500 Internal Server Error")
		return
	}
	t.Execute(w, b)
}

func main() {
	http.HandleFunc("/", handler)
	http.HandleFunc("/print", print)
	log.Fatal(http.ListenAndServe(":8070", nil))
}

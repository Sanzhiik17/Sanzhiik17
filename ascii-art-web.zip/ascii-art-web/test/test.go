package main

import (
	"fmt"
	"os"
	"strings"

	art "../ascii-art"
)

func main() {
	var val string
	var err error
	banners := art.GetBanners("standard" + ".txt")
	values := strings.Split(os.Args[1], "\\n")
	res := ""
	fmt.Println(values)
	for _, i := range values {
		val, err = art.CombineBanners(banners, i)
		if err != nil {
			//fmt.Fprintf(w, "400 Bad Request")
			return
		}
		// if index != len(values)-1 {
		// 	val += "\n"
		// }
		res += val
	}
	fmt.Println(res)
}

package main

import (
	"fmt"

	art ".."
)

func main() {
	banners := art.GetBanners("shadow.txt")
	fmt.Println(banners)
	banners = art.CombineBanners(banners, "asd")
}

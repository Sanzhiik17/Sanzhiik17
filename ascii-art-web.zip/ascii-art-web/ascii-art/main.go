package art

import (
	"bufio"
	"errors"
	"os"
	"strings"
)

func GetBanners(fileName string) ([][]string, error){
	var banners [][]string
	var banner []string
	file, err := os.Open(fileName)
	if err != nil {
		return banners,err
	}
	reader := bufio.NewReader(file)
	counter := 0
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			banners = append(banners, banner)
			break
		}
		// saving only 8 lines in each banner
		if counter > 8 {
			banners = append(banners, banner)
			banner = []string{}
			counter = 0
		}
		banner = append(banner, line)
		counter++
	}
	return banners,nil
}

func CombineBanners(banners [][]string, arg string) (string, error) {
	for _, value := range arg {
		if int(value) < 0 || int(value) > 127 {
			return "", errors.New("400 Bad Value")
		}
	}
	var requestedBanners [][]string
	var result []string
	for i := 0; i < len(arg); i++ {
		requestedBanners = append(requestedBanners, banners[int(arg[i])-32])
	}

	for i := 0; i < 8; i++ {
		combineStr := ""
		for _, banner := range requestedBanners {
			// to not include \n in the end of string
			lastChInd := len(banner[i]) - 1
			combineStr += banner[i][:lastChInd]
		}
		result = append(result, combineStr+"\n")
	}
	return strings.Join(result, ""), nil
}
